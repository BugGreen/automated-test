# This file will allow to install the package in editable mode
from setuptools import setup

if __name__ == "__main__":
    setup()